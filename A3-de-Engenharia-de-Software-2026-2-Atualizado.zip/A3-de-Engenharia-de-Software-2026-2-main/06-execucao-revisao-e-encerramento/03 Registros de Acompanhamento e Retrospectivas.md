# 6.3 REGISTROS DE ACOMPANHAMENTO E RETROSPECTIVAS

Para que seja possível acompanhar as atividades realizadas durante as Sprints, segue um modelo de registro que deverá ser preenchido conforme estas ocorram:

| **Registro** | **Campos obrigatórios** |
| --- | --- |
| Daily Scrum | Data; Sprint; progresso; plano até próxima Daily; impedimentos e responsável pelo tratamento. |
| Sprint Review | Data; participantes; incremento apresentado; critérios verificados; feedback; alterações no backlog. |
| Retrospectiva | Data; o que funcionou; dificuldades; causa; ação de melhoria; responsável; prazo; verificação na Sprint seguinte. |
