# 6.2 DEFINITION OF DONE E HOMOLOGAÇÃO

Para que um item do Product Backlog seja considerado concluído, não basta que a função desejada tenha sido implementada, sendo necessário que esta respeite os critérios de aceite, que seu código e documentação estejam revisados e versionados, que passe pelos testes correspondentes e que respeite os requisitos de segurança e acessibilidade que se aplicam a ela; além disso, o incremento deve estar integrado ao sistema. A Sprint Review permite analisar o incremento, mas não substitui a Definition of Done.

| **Área** | **Verificação planejada** | **Evidência** |
| --- | --- | --- |
| Pedidos e cobertura | Criar pedido válido; bloquear fora de 5 km e produto indisponível. | Casos de teste e resultado. |
| Pix e conciliação | Pagamento confirmado, falha, webhook duplicado, cancelamento e reembolso. | Logs sanitizados e teste de integração. |
| Entrega | Atribuir, coletar, rastrear e concluir; negar acesso indevido. | Teste de integração e autorização. |
| Acessibilidade | Teclado, foco, contraste e leitor de tela nos fluxos principais. | Checklist WCAG 2.2 AA e testes manuais. |
| Desempenho | 95% das solicitações em até 2 s; carga de 5.000 usuários; status em até 5 s. | Relatório de carga em ambiente representativo. |
| Operação | Calcular média de entregas concluídas dentro de 5 km, por período. | Relatório operacional; meta &lt; 35 min sujeita a dados reais. |
| Resiliência | Backup, restauração, disponibilidade e integridade. | Teste de recuperação e métricas de serviço. |
