# 6.4 ENCERRAMENTO E LIÇÕES APRENDIDAS

Com a Release finalizada, cabe ao Product Owner e aos Stakeholders verificar se o produto desenvolvido respeita o escopo e os critérios de aceite previamente estabelecidos, registrando as possíveis pendências e formalizando o aceite; posterior a isso, o Scrum Team deverá reunir a documentação, a versão do sistema, os resultados dos testes, as instruções de operação e os itens restantes do Product Backlog, sendo que as lições aprendidas serão definidas com base nas experiências obtidas ao longo das Sprints.

## 6.4.1 TERMO DE ACEITE E ENCERRAMENTO — MODELO

| **Campo** | **Preenchimento** |
| --- | --- |
| Projeto / release | BairroDelivery / v1.0.0 |
| Escopo entregue | A registrar após execução. |
| Evidências de homologação | A anexar após testes e Review. |
| Pendências e ressalvas | A registrar. |
| Decisão de aceite | Pendente — aceito / aceito com ressalvas / rejeitado. |
| Responsável pelo aceite | Product Owner — Jasnah; validação pelos stakeholders pertinentes. |
| Data e assinatura | A preencher no encerramento. |
