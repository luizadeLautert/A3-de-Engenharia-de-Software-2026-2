# 6.1 PLANO DE EXECUÇÃO E EVENTOS SCRUM

| **Evento** | **Frequência / participantes** | **Resultado esperado** |
| --- | --- | --- |
| Sprint Planning | Início de cada Sprint; Scrum Team. | Sprint Goal, seleção de itens e plano de trabalho. |
| Daily Scrum | 15 minutos por dia útil; Developers. | Inspeção do progresso e ajuste do plano; impedimentos registrados. |
| Sprint Review | Fim de cada Sprint; Scrum Team e stakeholders. | Inspeção do incremento, feedback e atualização do backlog. |
| Sprint Retrospective | Fim de cada Sprint, após Review; Scrum Team. | Melhoria concreta de processo para a Sprint seguinte. |
