# 1 INICIAÇÃO E VISÃO DO PRODUTO

Para o desenvolvimento do BairroDelivery, será utilizado o Scrum como metodologia ágil, sendo que as etapas estabelecidas no presente documento são referentes ao planejamento do projeto, cabendo à equipe validar e executar o que foi proposto.

## Documentos

- [1.1 CONTEXTO, JUSTIFICATIVA E OBJETIVOS](1.%20Contexto%2C%20Justificativa%20e%20objetivos.md)
- [1.3 STAKEHOLDERS E PAPÉIS SCRUM](02%20stakeholders%20e%20papeis%20scrum.md)
- [1.5 TERMO DE ABERTURA DO PROJETO (TAP)](03%20Termo%20de%20Abertura%20do%20Projeto.md)
- [1.6 MATRIZ DE STAKEHOLDERS](04%20Matriz%20de%20Stakeholders.md)
- [1.7 ESTRUTURA ANALÍTICA DO PROJETO (EAP)](05%20Estrutura%20Anal%C3%ADtica%20do%20Projeto.md)
