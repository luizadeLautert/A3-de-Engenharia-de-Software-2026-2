# BAIRRODELIVERY

Documentação do projeto de software

Documentação integrada  •  Versão 1.0  •  26/11/2026

## SUMÁRIO

- [1 INICIAÇÃO E VISÃO DO PRODUTO](01-project-overview/README.md)
- [2 ESCOPO E BACKLOG DO PRODUTO](02-requerimentos-e-product-backlog/README.md)
- [3 MODELAGEM E ARQUITETURA DE SOFTWARE](03-modelagem-e-arquitetura/README.md)
- [4 PLANEJAMENTO ÁGIL E CICLO DE SPRINTS](04-planejamento-agil-e-sprints/README.md)
- [5 GERÊNCIA DE CONFIGURAÇÃO E PRÁTICAS COLABORATIVAS](05-gerencia-de-configuracao-e-ferramentas/README.md)
- [6 EXECUÇÃO, REVISÃO E ENCERRAMENTO](06-execucao-revisao-e-encerramento/README.md)
- [7 REFERÊNCIAS BIBLIOGRÁFICAS](07-referencias/README.md)
