# 2.6 PRODUCT BACKLOG

## 2.6.1 OBJETIVO DO PRODUTO

Dados os objetivos previamente estabelecidos, o produto a ser desenvolvido consiste em uma plataforma de delivery que possibilite a conexão entre consumidores, restaurantes e entregadores dentro de um raio de 5 km, utilizando-se de taxas reduzidas, pagamento e conciliação via Pix, rastreamento em tempo real e funcionalidades para inclusão de PCD.

## 2.6.2 CLASSIFICAÇÃO DE PRIORIDADES

Para definir a prioridade de cada um dos itens do Product Backlog, será utilizado o método MoSCoW, que permite classificar os itens em quatro categorias, conforme:

- Must Have: são as funcionalidades indispensáveis para o produto;
- Should Have: são as funcionalidades que, por mais que sejam importantes, não são indispensáveis;
- Could Have: são as funcionalidades desejáveis para o produto;
- Won't Have: são as funcionalidades que não serão contempladas na versão atual.

## 2.6.3 ESTIMATIVA DE ESFORÇO

Para estimarmos o esforço necessário para a implementação de cada item, usaremos Story Points, utilizando os seguintes valores da sequência de Fibonacci:

1, 2, 3, 5, 8, 13, 21.

É importante entender que os valores utilizados não correspondem a uma unidade de tempo, somente estabelecem uma relação entre a complexidade, o esforço e as incertezas dos diversos itens.

Os valores dos itens PB-026 a PB-030 foram definidos como estimativas iniciais, cabendo aos Developers validar os valores atribuídos.

## 2.6.4 PRODUCT BACKLOG

| **ID** | **Item do Backlog** | **História de Usuário** | **Prioridade** | **Story Points** | **Status** |
| --- | --- | --- | --- | --- | --- |
| PB-001 | Cadastro de usuários | HU-001 | Must Have | 5 | Pendente |
| PB-002 | Autenticação | HU-002 | Must Have | 5 | Pendente |
| PB-003 | Controle de permissões | HU-020 | Must Have | 5 | Pendente |
| PB-004 | Gerenciamento de restaurantes | HU-021 | Must Have | 5 | Pendente |
| PB-005 | Gerenciamento de cardápios | HU-011 | Must Have | 8 | Pendente |
| PB-006 | Controle de disponibilidade | HU-012 | Must Have | 3 | Pendente |
| PB-007 | Consulta geográfica de restaurantes | HU-005 | Must Have | 8 | Pendente |
| PB-008 | Visualização de cardápios | HU-006 | Must Have | 3 | Pendente |
| PB-009 | Gerenciamento do carrinho | HU-007 | Must Have | 5 | Pendente |
| PB-010 | Confirmação de pedidos | HU-008 | Must Have | 5 | Pendente |
| PB-011 | Processamento de pagamentos | HU-008 | Must Have | 13 | Pendente |
| PB-012 | Recebimento de pedidos | HU-013 | Must Have | 5 | Pendente |
| PB-013 | Atualização do status dos pedidos | HU-014 | Must Have | 5 | Pendente |
| PB-014 | Atribuição de entregadores | HU-016 | Must Have | 8 | Pendente |
| PB-015 | Registro de coleta | HU-017 | Must Have | 3 | Pendente |
| PB-016 | Confirmação de entrega | HU-018 | Must Have | 3 | Pendente |
| PB-017 | Acompanhamento de pedidos | HU-009 | Must Have | 5 | Pendente |
| PB-018 | Recuperação de senha | HU-003 | Should Have | 3 | Pendente |
| PB-019 | Gerenciamento de perfil | HU-004 | Should Have | 3 | Pendente |
| PB-020 | Histórico de pedidos | HU-010, HU-015 | Should Have | 5 | Pendente |
| PB-021 | Histórico de entregas | HU-019 | Should Have | 3 | Pendente |
| PB-022 | Monitoramento administrativo | HU-022 | Should Have | 5 | Pendente |
| PB-023 | Relatórios operacionais | HU-023 | Must Have | 8 | Pendente |
| PB-024 | Processamento de reembolsos | HU-029 | Must Have | 8 | Pendente |
| PB-025 | Cancelamento de pedidos | HU-030 | Must Have | 5 | Pendente |
| PB-026 | Rastreamento em tempo real | HU-024 | Must Have | 13 | Pendente |
| PB-027 | Integração de pagamento via Pix | HU-025 | Must Have | 8 | Pendente |
| PB-028 | Conciliação financeira via Pix | HU-026 | Must Have | 8 | Pendente |
| PB-029 | Acessibilidade das interfaces | HU-027 | Must Have | 8 | Pendente |
| PB-030 | Monitoramento do tempo médio de entrega | HU-028 | Must Have | 5 | Pendente |
