# 2 ESCOPO E BACKLOG DO PRODUTO

## Documentos

- [2.1 REQUISITOS FUNCIONAIS](01%20requisitos%20funcionais.md)
- [2.2 REQUISITOS NÃO FUNCIONAIS](02%20Requisitos%20Nao%20Funcionais.md)
- [2.3 REGRAS DE NEGÓCIO](03%20Regras%20de%20Neg%C3%B3cios.md)
- [2.4 DECOMPOSIÇÃO DO PROBLEMA](04%20Decomposi%C3%A7%C3%A3o%20do%20Problema.md)
- [2.5 HISTÓRIAS DE USUÁRIO](05%20Historias%20de%20Usu%C3%A1rios.md)
- [2.6 PRODUCT BACKLOG](06%20Product%20Backlog.md)
