# 7 REFERÊNCIAS BIBLIOGRÁFICAS

PRESSMAN, Roger S.; MAXIM, Bruce R. Engenharia de software: uma abordagem profissional. Porto Alegre: Grupo A, 2021.

SOMMERVILLE, Ian. Engenharia de software. 10. ed. São Paulo: Pearson, 2019.

VALENTE, Marco Tulio. Engenharia de software moderna: princípios e práticas para desenvolvimento de software com produtividade. 2020.

VAZQUEZ, Carlos Eduardo; SIMÕES, Guilherme Siqueira. Engenharia de requisitos: software orientado ao negócio. Rio de Janeiro: Brasport, 2016.

SCHWABER, Ken; SUTHERLAND, Jeff. O Guia do Scrum. 2020. Disponível em: https://scrumguides.org/.

WORLD WIDE WEB CONSORTIUM (W3C). Web Content Accessibility Guidelines (WCAG) 2.2. Disponível em: https://www.w3.org/TR/WCAG22/.

BRASIL. Lei nº 13.709, de 14 de agosto de 2018. Lei Geral de Proteção de Dados Pessoais (LGPD).

As referências acima servem de base para o planejamento do projeto; posterior à escolha do provedor Pix, do serviço de mapas e das tecnologias de implementação, deverão ser acrescentadas as referências referentes a estes.
